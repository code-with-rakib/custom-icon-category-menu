<?php
/**
 * Plugin Name: Left Category Setup
 * Description: Displays a custom category menu with item-specific icons and a bottom discount banner using a shortcode, with customizable colors.
 * Version: 1.2
 * Author: Rakib Hasan
 * License: GPL2+
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// ----------------------------------------------------
// A. ENQUEUE SCRIPTS AND STYLES & COLOR FUNCTIONS
// ----------------------------------------------------

/**
 * Helper function to slightly change color brightness for hover effects.
 */
function lcs_adjust_brightness($hex, $steps) {
    // Remove # if present
    $hex = str_replace('#', '', $hex);

    // Get RGB values
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));

    // Adjust brightness
    $r = max(0, min(255, $r + $steps));
    $g = max(0, min(255, $g + $steps));
    $b = max(0, min(255, $b + $steps));

    // Convert back to hex
    $r_hex = str_pad(dechex($r), 2, '0', STR_PAD_LEFT);
    $g_hex = str_pad(dechex($g), 2, '0', STR_PAD_LEFT);
    $b_hex = str_pad(dechex($b), 2, '0', STR_PAD_LEFT);

    return '#' . $r_hex . $g_hex . $b_hex;
}


function lcs_enqueue_assets() {
    // Enqueue Font Awesome for icons
    wp_enqueue_style( 'font-awesome-lcs', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css', array(), '6.5.2' );

    // Get color settings
    $primary_color = get_option( 'lcs_primary_color', '#007bff' );
    $discount_bg_color = get_option( 'lcs_discount_bg_color', '#212529' );

    // Define custom CSS variables based on settings
    $custom_css = "
        .lcs-category-menu-wrap {
            --lcs-primary-color: {$primary_color};
            --lcs-discount-bg: {$discount_bg_color};
            --lcs-discount-bg-hover: " . lcs_adjust_brightness( $discount_bg_color, 15 ) . ";
            --lcs-primary-color-hover: " . lcs_adjust_brightness( $primary_color, -10 ) . ";
        }
    ";
    
    // Add inline CSS to the head
    wp_add_inline_style( 'lcs-styles', $custom_css );

    // Enqueue custom styles (where CSS variables are used)
    wp_enqueue_style( 'lcs-styles', plugin_dir_url( __FILE__ ) . 'style.css' );

    // Enqueue admin scripts for media uploader and settings
    if ( is_admin() ) {
        wp_enqueue_media();
        wp_enqueue_script( 'lcs-admin-script', plugin_dir_url( __FILE__ ) . 'admin-script.js', array('jquery'), '1.0', true );
    }
}
add_action( 'wp_enqueue_scripts', 'lcs_enqueue_assets' );
add_action( 'admin_enqueue_scripts', 'lcs_enqueue_assets' );


// ----------------------------------------------------
// B. PLUGIN SETTINGS PAGE (Admin)
// ----------------------------------------------------

function lcs_add_admin_menu() {
    add_menu_page(
        'Left Category Setup',
        'Left Category Setup',
        'manage_options',
        'left-category-setup',
        'lcs_settings_page_content',
        'dashicons-menu-alt', // WordPress icon for the menu
        6
    );
}
add_action( 'admin_menu', 'lcs_add_admin_menu' );

function lcs_settings_init() {
    // General Settings
    register_setting( 'lcs_group', 'lcs_selected_menu' );
    
    // Color Settings
    register_setting( 'lcs_group', 'lcs_primary_color' );
    register_setting( 'lcs_group', 'lcs_discount_bg_color' );

    // Discount Settings
    register_setting( 'lcs_group', 'lcs_discount_text' );
    register_setting( 'lcs_group', 'lcs_discount_link' );

    // Section 1: General
    add_settings_section(
        'lcs_main_section',
        'General Settings',
        null,
        'left-category-setup'
    );

    add_settings_field(
        'lcs_selected_menu_field',
        'Select Menu',
        'lcs_selected_menu_callback',
        'left-category-setup',
        'lcs_main_section'
    );
    
    // Section 2: Colors
    add_settings_section(
        'lcs_color_section',
        'Color Settings',
        null,
        'left-category-setup'
    );

    add_settings_field(
        'lcs_primary_color_field',
        'Primary Color (Header/Icon)',
        'lcs_primary_color_callback',
        'left-category-setup',
        'lcs_color_section'
    );

    add_settings_field(
        'lcs_discount_bg_color_field',
        'Discount Banner BG Color',
        'lcs_discount_bg_color_callback',
        'left-category-setup',
        'lcs_color_section'
    );

    // Section 3: Discount Banner
    add_settings_section(
        'lcs_discount_section',
        'Discount Banner Settings',
        null,
        'left-category-setup'
    );

    add_settings_field(
        'lcs_discount_text_field',
        'Discount Text',
        'lcs_discount_text_callback',
        'left-category-setup',
        'lcs_discount_section'
    );

    add_settings_field(
        'lcs_discount_link_field',
        'Discount Link URL',
        'lcs_discount_link_callback',
        'left-category-setup',
        'lcs_discount_section'
    );
}
add_action( 'admin_init', 'lcs_settings_init' );

function lcs_selected_menu_callback() {
    $menus = wp_get_nav_menus();
    $selected_menu = get_option( 'lcs_selected_menu' );
    ?>
    <select name="lcs_selected_menu">
        <option value="">— Select a Menu —</option>
        <?php foreach ( $menus as $menu ) : ?>
            <option value="<?php echo esc_attr( $menu->term_id ); ?>" <?php selected( $selected_menu, $menu->term_id ); ?>>
                <?php echo esc_html( $menu->name ); ?>
            </option>
        <?php endforeach; ?>
    </select>
    <p class="description">Select the WordPress menu to display in the category setup.</p>
    <?php
}

function lcs_primary_color_callback() {
    $primary_color = get_option( 'lcs_primary_color', '#007bff' ); 
    echo '<input type="color" name="lcs_primary_color" value="' . esc_attr( $primary_color ) . '" class="regular-text" />';
    echo '<p class="description">Used for the menu header background and category icons.</p>';
}

function lcs_discount_bg_color_callback() {
    $discount_bg_color = get_option( 'lcs_discount_bg_color', '#212529' ); 
    echo '<input type="color" name="lcs_discount_bg_color" value="' . esc_attr( $discount_bg_color ) . '" class="regular-text" />';
    echo '<p class="description">Background color for the HUGE SALE banner.</p>';
}

function lcs_discount_text_callback() {
    $discount_text = get_option( 'lcs_discount_text', 'HUGE SALE - 70% OFF' );
    echo '<input type="text" name="lcs_discount_text" value="' . esc_attr( $discount_text ) . '" class="regular-text" />';
}

function lcs_discount_link_callback() {
    $discount_link = get_option( 'lcs_discount_link', '#' );
    echo '<input type="url" name="lcs_discount_link" value="' . esc_url( $discount_link ) . '" class="regular-text" />';
}


function lcs_settings_page_content() {
    // Check user capabilities
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <form action="options.php" method="post">
            <?php
            settings_fields( 'lcs_group' );
            do_settings_sections( 'left-category-setup' );
            submit_button( 'Save Settings' );
            ?>
        </form>
        
        <h2>Menu Item Icons Setup</h2>
        <p>Go to **Appearance -> Menus**, edit your selected menu, and you will find fields to add icons to each item.</p>
        <p>You can use Font Awesome icon classes (e.g., <code>fas fa-tshirt</code> for Fashion) or upload an image URL.</p>
        
        <h3>Shortcode to Use: <code>[left_category_menu]</code></h3>

    </div>
    <?php
}

// ----------------------------------------------------
// C. CUSTOM FIELDS FOR MENU ITEMS (Icon/Image)
// ----------------------------------------------------

// Add custom fields to nav menu items
function lcs_add_custom_fields_to_menu_item( $item_id, $item ) {
    $icon_type = get_post_meta( $item_id, '_menu_item_icon_type', true );
    $icon_value = get_post_meta( $item_id, '_menu_item_icon_value', true );
    ?>
    <div style="clear: both; margin-top: 10px; border-top: 1px solid #ccc; padding-top: 10px;">
        <span class="description">Category Icon/Image:</span><br>
        <p class="field-custom-icon description description-wide">
            <label for="edit-menu-item-icon-type-<?php echo esc_attr( $item_id ); ?>">
                Icon Type
            </label>
            <select id="edit-menu-item-icon-type-<?php echo esc_attr( $item_id ); ?>" name="menu-item-icon-type[<?php echo esc_attr( $item_id ); ?>]">
                <option value="none" <?php selected( $icon_type, 'none' ); ?>>None</option>
                <option value="fa" <?php selected( $icon_type, 'fa' ); ?>>Font Awesome Class</option>
                <option value="image" <?php selected( $icon_type, 'image' ); ?>>Image URL</option>
            </select>
        </p>
        
        <p class="field-custom-icon-value description description-wide">
            <label for="edit-menu-item-icon-value-<?php echo esc_attr( $item_id ); ?>">
                Icon Value (Class or URL)
            </label>
            <input type="text" id="edit-menu-item-icon-value-<?php echo esc_attr( $item_id ); ?>" class="widefat code edit-menu-item-custom" name="menu-item-icon-value[<?php echo esc_attr( $item_id ); ?>]" value="<?php echo esc_attr( $icon_value ); ?>">
            <button class="button lcs-media-uploader" data-target="#edit-menu-item-icon-value-<?php echo esc_attr( $item_id ); ?>" style="display: <?php echo $icon_type === 'image' ? 'inline-block' : 'none'; ?>;">Upload Image</button>
        </p>
    </div>
    <?php
}
add_action( 'wp_nav_menu_item_custom_fields', 'lcs_add_custom_fields_to_menu_item', 10, 2 );

// Save custom fields
function lcs_save_custom_fields( $menu_id, $menu_item_db_id ) {
    if ( isset( $_POST['menu-item-icon-type'][$menu_item_db_id] ) ) {
        $icon_type = sanitize_text_field( $_POST['menu-item-icon-type'][$menu_item_db_id] );
        update_post_meta( $menu_item_db_id, '_menu_item_icon_type', $icon_type );
    }

    if ( isset( $_POST['menu-item-icon-value'][$menu_item_db_id] ) ) {
        $icon_value = sanitize_text_field( $_POST['menu-item-icon-value'][$menu_item_db_id] );
        update_post_meta( $menu_item_db_id, '_menu_item_icon_value', $icon_value );
    }
}
add_action( 'wp_update_nav_menu_item', 'lcs_save_custom_fields', 10, 2 );


// ----------------------------------------------------
// D. CUSTOM MENU WALKER (For adding icon and arrow)
// ----------------------------------------------------

class LCS_Walker_Nav_Menu extends Walker_Nav_Menu {
    function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
        global $wp_query;

        // Start element HTML
        $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';

        $classes = empty( $item->classes ) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . $item->ID;

        $class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args, $depth ) );
        $class_names = ' class="' . esc_attr( $class_names ) . '"';

        $output .= $indent . '<li id="menu-item-'. esc_attr( $item->ID ) . '"' . $class_names . '>';

        $attributes  = ! empty( $item->attr_title ) ? ' title="'  . esc_attr( $item->attr_title ) .'"' : '';
        $attributes .= ! empty( $item->target )     ? ' target="' . esc_attr( $item->target     ) .'"' : '';
        $attributes .= ! empty( $item->xfn )        ? ' rel="'    . esc_attr( $item->xfn        ) .'"' : '';
        $attributes .= ! empty( $item->url )        ? ' href="'   . esc_url( $item->url        ) .'"' : '';

        $item_output = $args->before;
        $item_output .= '<a'. $attributes .'>';

        // --- Custom Icon/Image Start ---
        $icon_type = get_post_meta( $item->ID, '_menu_item_icon_type', true );
        $icon_value = get_post_meta( $item->ID, '_menu_item_icon_value', true );
        $icon_html = '';

        if ( 'fa' === $icon_type && ! empty( $icon_value ) ) {
            $icon_html = '<i class="lcs-icon ' . esc_attr( $icon_value ) . '"></i> ';
        } elseif ( 'image' === $icon_type && ! empty( $icon_value ) ) {
            $icon_html = '<img src="' . esc_url( $icon_value ) . '" class="lcs-icon lcs-image-icon" alt="' . esc_attr( $item->title ) . ' Icon" />';
        }

        $item_output .= $icon_html;
        // --- Custom Icon/Image End ---

        // Item Title (Wrapped in lcs-menu-title for 18px bold style)
        $item_output .= '<span class="lcs-menu-title">';
        $item_output .= $args->link_before . apply_filters( 'the_title', $item->title, $item->ID ) . $args->link_after;
        $item_output .= '</span>';
        
        // --- Right Arrow Icon ---
        $item_output .= ' <span class="lcs-right-arrow">></span>'; // Right arrow icon
        // --- Right Arrow Icon End ---

        $item_output .= '</a>';
        $item_output .= $args->after;

        $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
    }
}

// ----------------------------------------------------
// E. SHORTCODE FUNCTION
// ----------------------------------------------------

function lcs_shortcode_function( $atts ) {
    $menu_id = get_option( 'lcs_selected_menu' );
    $discount_text = get_option( 'lcs_discount_text' );
    $discount_link = get_option( 'lcs_discount_link' );

    if ( empty( $menu_id ) ) {
        if ( current_user_can( 'manage_options' ) ) {
             return '<p style="color:red; padding: 10px; border: 1px dashed red;">Error: Please select a menu in Left Category Setup settings.</p>';
        } else {
            return '';
        }
    }

    ob_start(); // Start output buffering
    ?>
    <div class="lcs-category-menu-wrap">
        <div class="lcs-header">
            <i class="fas fa-bars lcs-menu-toggle-icon"></i> 
            <span class="lcs-title">SHOP BY CATEGORY</span>
        </div>
        <nav class="lcs-menu-container">
            <?php
            wp_nav_menu( array(
                'menu'        => $menu_id,
                'container'   => false, // No outer <div> container
                'menu_class'  => 'lcs-menu',
                'depth'       => 1, // Only show top level items
                'walker'      => new LCS_Walker_Nav_Menu(),
            ) );
            ?>
        </nav>
        
        <?php if ( ! empty( $discount_text ) ) : ?>
        <a href="<?php echo esc_url( $discount_link ); ?>" class="lcs-discount-banner">
            <?php echo esc_html( $discount_text ); ?>
        </a>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean(); // Return the buffered output
}
add_shortcode( 'left_category_menu', 'lcs_shortcode_function' );

// ----------------------------------------------------
// F. ADMIN JS FOR MEDIA UPLOADER (For admin-script.js)
// ----------------------------------------------------

// NOTE: The following JavaScript should be placed in a separate file named `admin-script.js` 
// in your plugin directory for best practice.

/*
(function($) {
    'use strict';
    
    // Media Uploader functionality for custom menu images
    $(document).on('click', '.lcs-media-uploader', function(e) {
        e.preventDefault();

        var button = $(this);
        var target = button.data('target');
        var custom_uploader = wp.media({
            title: 'Select Category Icon Image',
            library: { type: 'image' },
            button: { text: 'Use this image' },
            multiple: false
        }).on('select', function() {
            var attachment = custom_uploader.state().get('selection').first().toJSON();
            $(target).val(attachment.url).trigger('change');
            button.text('Change Image');
        }).open();
    });
    
    // Show/hide upload button based on icon type selection
    $(document).on('change', 'select[name^="menu-item-icon-type"]', function() {
        var type = $(this).val();
        var id_parts = $(this).attr('id').split('-');
        var item_id = id_parts[id_parts.length - 1]; 
        
        var input_field = $('#edit-menu-item-icon-value-' + item_id);
        var button = input_field.next('.lcs-media-uploader');
        
        if (type === 'image') {
            button.show();
        } else {
            button.hide();
        }
    });
    
    // Initial check on load for existing menu items
    $('select[name^="menu-item-icon-type"]').trigger('change');

})(jQuery);
*/